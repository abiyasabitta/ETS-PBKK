@extends('layouts.app')

@section('content')


            <div id="slides" class="cover-slides">
                <ul class="slides-container">
                    <li class="text-left">
                        <img src="{{url('/img/slider-01.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Live Dinner Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="text-left">
                        <img src="{{url('/img/slider-02.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Live Dinner Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="text-left">
                        <img src="{{url('/img/slider-03.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Yamifood Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="slides-navigation">
                    <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                </div>
            </div>
            <!-- End slides -->
            
        </div>
        <!-- ALL JS FILES -->
        <script src="{{ asset('/js/welcome/jquery-3.2.1.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/popper.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/bootstrap.min.js') }}" defer></script>
        <!-- ALL PLUGINS -->
        <script src="{{ asset('/js/welcome/jquery.superslides.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/images-loded.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/isotope.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/baguetteBox.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/form-validator.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/contact-form-script.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/custom.js') }}" defer></script>

@endsection
