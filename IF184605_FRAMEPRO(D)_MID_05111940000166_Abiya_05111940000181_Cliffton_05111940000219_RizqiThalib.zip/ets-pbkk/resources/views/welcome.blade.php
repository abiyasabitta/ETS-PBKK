<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        

        <!-- Styles -->
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{ asset('/css/bootstrap.min.css') }}" defer>    
        <!-- Site CSS -->
        <link rel="stylesheet" href="{{ asset('/css/style.css') }}" defer>    
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="{{ asset('/css/responsive.css') }}" defer>
        <!-- Custom CSS -->
        <link rel="stylesheet" href="{{ asset('/css/custom.css') }}" defer>
        <style>
            
        </style>

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased" style="background-color:#d65106;">
    <header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="index.html">
					<img src="images/logo.png" alt="" />
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-rs-food">
					<ul class="navbar-nav ml-auto">
                        @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item active">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a>
                            </li>
                            <li class="nav-item">
                                    <a class="nav-link" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                        
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->
            <div id="slides" class="cover-slides">
                <ul class="slides-container">
                    <li class="text-left">
                        <img src="{{url('/img/slider-01.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Live Dinner Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="text-left">
                        <img src="{{url('/img/slider-02.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Live Dinner Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="text-left">
                        <img src="{{url('/img/slider-03.jpg')}}" alt="">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <h1 class="m-b-20"><strong>Welcome To <br> Yamifood Restaurant</strong></h1>
                                    <p class="m-b-40">See how your users experience your website in realtime or view  <br> 
                                    trends to see any changes in performance over time.</p>
                                    <p><a class="btn btn-lg btn-circle btn-outline-new-white" href="#">Reservation</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="slides-navigation">
                    <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                </div>
            </div>
            <!-- End slides -->
            
        </div>
        <!-- ALL JS FILES -->
        <script src="{{ asset('/js/welcome/jquery-3.2.1.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/popper.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/bootstrap.min.js') }}" defer></script>
        <!-- ALL PLUGINS -->
        <script src="{{ asset('/js/welcome/jquery.superslides.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/images-loded.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/isotope.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/baguetteBox.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/form-validator.min.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/contact-form-script.js') }}" defer></script>
        <script src="{{ asset('/js/welcome/custom.js') }}" defer></script>
    </body>
</html>
