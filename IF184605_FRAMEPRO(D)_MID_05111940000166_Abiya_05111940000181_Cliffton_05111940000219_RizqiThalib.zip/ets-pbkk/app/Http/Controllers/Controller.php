<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Route;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    
}


Route::get('/shop', function () {

    $item = \DB::table('item')->get();
    $ingredients = \DB::table('ingredients')->get();

    return view('shop', ['item' => $item, 'ingredients' => $ingredients]);
});
