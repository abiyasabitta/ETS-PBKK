<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class createcart extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cart', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('id_ing')->unsigned();
            $table->integer('id_item')->unsigned();
            $table->integer('id_user')->unsigned();
            $table->foreign('id_ing')->references('id')->on('ingredients');
            $table->foreign('id_item')->references('id')->on('item');
            $table->foreign('id_user')->references('id')->on('users');
            $table->string('notes');
            $table->integer('qty');
            $table->integer('price');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cart');
    }
}
