<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $nama=['Roll', 'Bun', 'Pasty'];
        $harga=[10000, 20000, 30000];
        for($i=0; $i < 3; $i++){
            \DB::table('item')->insert([
                'name' => $nama[$i],
                'price' => $harga[$i]
            ]);
        }

        $nama2=['Vegetable', 'Fish', 'Chicken'];
        $harga2=[20000, 30000, 10000];
        for($j=0; $j < 3; $j++){
            \DB::table('ingredients')->insert([
                'name' => $nama2[$j],
                'price' => $harga2[$j]
            ]);
        }

    }
}
